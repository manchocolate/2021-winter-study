package com.zhang.dao.StuUser;

import com.zhang.pojo.StuUser;
import com.zhang.utils.JdbcUtils;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
//登录验证
public class UserDaoImpl implements UserDao {
    //得到要 登录的用户
    @Override
    public StuUser getLoginUser(Connection con, String name) throws SQLException {
        ResultSet rs =null;
        PreparedStatement sta = null;
        StuUser user =null;
        if(con!=null){
            String sql = "select * from stu_user where name=?";
            Object[] params = {name};

            rs = JdbcUtils.execute(con,sta,rs,sql,params);
            if(rs.next()){

                user = new StuUser();
                user.setUserid(rs.getString("userid"));
                user.setAge(rs.getLong("age"));
                user.setDeep(rs.getString("deep"));
                user.setDate(rs.getDate("date"));
                user.setName(rs.getString("name"));
                user.setPlace(rs.getString("place"));
                user.setSchoolage(rs.getLong("schoolage"));
                user.setProve(rs.getString("prove"));
                user.setSchool(rs.getString("school"));
            }
                JdbcUtils.release(con,sta,rs);


        }
    return user;
    }



}

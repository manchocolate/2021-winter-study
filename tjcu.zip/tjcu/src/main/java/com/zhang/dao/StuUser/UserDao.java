package com.zhang.dao.StuUser;

import com.zhang.pojo.StuUser;

import java.sql.Connection;
import java.sql.SQLException;

public interface UserDao {
    //得到登录的用户
    public StuUser getLoginUser(Connection con,String name) throws SQLException;


}

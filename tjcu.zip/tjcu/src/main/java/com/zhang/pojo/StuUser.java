package com.zhang.pojo;


public class StuUser {

  private String userid;
  private String name;
  private String deep;
  private String place;
  private String prove;
  private java.sql.Date date;
  private long age;
  private String school;
  private long schoolage;


  public String getUserid() {
    return userid;
  }

  public void setUserid(String userid) {
    this.userid = userid;
  }


  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }


  public String getDeep() {
    return deep;
  }

  public void setDeep(String deep) {
    this.deep = deep;
  }


  public String getPlace() {
    return place;
  }

  public void setPlace(String place) {
    this.place = place;
  }


  public String getProve() {
    return prove;
  }

  public void setProve(String prove) {
    this.prove = prove;
  }


  public java.sql.Date getDate() {
    return date;
  }

  public void setDate(java.sql.Date date) {
    this.date = date;
  }


  public long getAge() {
    return age;
  }

  public void setAge(long age) {
    this.age = age;
  }


  public String getSchool() {
    return school;
  }

  public void setSchool(String school) {
    this.school = school;
  }


  public long getSchoolage() {
    return schoolage;
  }

  public void setSchoolage(long schoolage) {
    this.schoolage = schoolage;
  }

}

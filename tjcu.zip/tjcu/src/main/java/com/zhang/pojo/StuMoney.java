package com.zhang.pojo;


public class StuMoney {

  private String deep;
  private long moeny;


  public String getDeep() {
    return deep;
  }

  public void setDeep(String deep) {
    this.deep = deep;
  }


  public long getMoeny() {
    return moeny;
  }

  public void setMoeny(long moeny) {
    this.moeny = moeny;
  }

}

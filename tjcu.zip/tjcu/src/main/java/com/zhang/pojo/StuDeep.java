package com.zhang.pojo;


public class StuDeep {

  private String deep;


  public String getDeep() {
    return deep;
  }

  public void setDeep(String deep) {
    this.deep = deep;
  }

}

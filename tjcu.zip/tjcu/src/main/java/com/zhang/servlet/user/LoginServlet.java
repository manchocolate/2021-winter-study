package com.zhang.servlet.user;

import com.zhang.pojo.StuUser;
import com.zhang.service.user.UserService;
import com.zhang.service.user.UserServiceImpl;
import com.zhang.utils.Constants;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

public class LoginServlet extends HttpServlet {
    //Servlet:控制层 ，调用业务层代码
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println("LoginServlet--start....");
        //获取用户名和密码
        String name = req.getParameter("name");
        String userid = req.getParameter("userid");
        /*System.out.println(name);
        System.out.println(userid);*/
        //和数据库中的密码进行对比 调用业务层
        UserServiceImpl userService = new UserServiceImpl();
        StuUser user = userService.login(name,userid);//到这里把登录的人查出来
        //如果查到
        if(user!=null){
            //将用户信息放到SESSION中
            req.getSession().setAttribute(Constants.USER_SESSION,user);
            resp.sendRedirect("frame.jsp");
        }else {//查无此人
            //转发回登陆页面
            resp.sendRedirect("login.jsp");
        }

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
}

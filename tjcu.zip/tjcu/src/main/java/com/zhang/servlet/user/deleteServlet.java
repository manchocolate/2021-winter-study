package com.zhang.servlet.user;

import com.zhang.service.user.UserServiceImpl;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;

public class deleteServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println("deleteServlet--start....");
        String userid = req.getParameter("userid");
        int i;
        UserServiceImpl userService = new UserServiceImpl();
        i = userService.deleteStuUser(userid);
        System.out.println(i);
        if(i!=0){
            PrintWriter out = resp.getWriter();
            out.println("删除成功");
            resp.setHeader("refresh","1,url=frame.jsp");
        }else {
            PrintWriter out = resp.getWriter();
            out.println("注册失败即将返回登录页");
            resp.setHeader("refresh","1,url=login.jsp");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
}

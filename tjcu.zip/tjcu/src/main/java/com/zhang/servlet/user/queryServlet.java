package com.zhang.servlet.user;


import com.zhang.utils.JdbcUtils;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class queryServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        PrintWriter writer = resp.getWriter();
        String id = req.getParameter("userid");
        String deep = req.getParameter("deep");
        System.out.println("id:"+id);
        System.out.println("deep"+deep);
        //判断正误
        /*System.out.println(deep!=null);
        System.out.println(deep==null);*/
        /*System.out.println(id!=null&deep.length()==0);*/
        if(id.length()!=0&deep.length()==0){
            idQueryServlet(id,resp);
        }else if (id.length()==0&deep.length()!=0){
            deepQueryServlet(deep,resp);
        }else {
            writer.println("id和deep二选一，即将返回登陆界面");
            resp.setHeader("refresh","1,url=login.jsp");
        }
        writer.println("<a href=\"register.jsp\">注册</a>\n" +
                "    <a href=\"delete.jsp\">根据id删除信息</a>\n" +
                "    <a href=\"update.jsp\">根据id修改信息</a>\n" +
                "    <a href=\"/tjcu_war/show.do\">查询所有信息</a>\n" +
                "    <a href=\"query.jsp\">id和贫困程度查询</a>"+
                "    <a href=\"sort.jsp\">排序</a>");


    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }

    public  void  idQueryServlet(String id,HttpServletResponse resp){
        Connection con = null;
        PreparedStatement sta = null;
        ResultSet rs =null;
        PrintWriter out = null;
        try {
            out = resp.getWriter();
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            String sql ="select * from stu_user where userid = ?";
            con = JdbcUtils.getConnection();
            sta = con.prepareStatement(sql);
            sta.setString(1,id);
            rs = sta.executeQuery();
            if(rs == null){
                out.println("id有误返回登陆界面");
                resp.setHeader("refresh","1,url=login.jsp");
            }else {
                while (rs.next()) {
                    out.println(
                            "id:" +
                                    rs.getString("userid") + "   " +
                                    "年龄:" +
                                    rs.getLong("age") + "   " +
                                    "贫困程度:" +
                                    rs.getString("deep") + "   " +
                                    "日期:" +
                                    rs.getDate("date") + "   " +
                                    "姓名:" +
                                    rs.getString("name") + "   " +
                                    "籍贯:" +
                                    rs.getString("place") + "   " +
                                    "学制:" +
                                    rs.getLong("schoolage") + "   " +
                                    "证明:" +
                                    rs.getString("prove") + "   " +
                                    "学校:" +
                                    rs.getString("school") + "<br>"
                    );
                }
            }

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }finally {
            JdbcUtils.release(con,sta,rs);
        }
    }
    public  void deepQueryServlet(String deep,HttpServletResponse resp){
        Connection con =null;
        PreparedStatement sta = null;
        ResultSet rs =null;
        String sql = "select * from stu_user where deep=?";
        try {
            con = JdbcUtils.getConnection();
            sta = con.prepareStatement(sql);
            sta.setString(1,deep);
            rs = sta.executeQuery();
            PrintWriter out = null;
            try {
                out = resp.getWriter();
            } catch (IOException e) {
                e.printStackTrace();
            }
            if(rs == null){
                out.println("deep有误返回登陆界面");
                resp.setHeader("refresh","1,url=login.jsp");
            }else {
            while (rs.next()){
                out.println(
                        "id:"+
                                rs.getString("userid")+"   "+
                                "年龄:"+
                                rs.getLong("age")+"   "+
                                "贫困程度:"+
                                rs.getString("deep")+"   "+
                                "日期:"+
                                rs.getDate("date")+"   "+
                                "姓名:"+
                                rs.getString("name")+"   "+
                                "籍贯:"+
                                rs.getString("place")+"   "+
                                "学制:"+
                                rs.getLong("schoolage")+"   "+
                                "证明:"+
                                rs.getString("prove")+"   "+
                                "学校:"+
                                rs.getString("school")+"<br>"
                );

            }
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }finally {
            JdbcUtils.release(con,sta,rs);
        }

    }
}

package com.zhang.servlet.user;

import com.zhang.pojo.StuUser;
import com.zhang.service.user.UserServiceImpl;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;

public class AddServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println("AddServlet--start....");
         String userid =req.getParameter("userid");

         String name = req.getParameter("name");
         String deep = req.getParameter("deep");
         String place = req.getParameter("place");
         String prove = req.getParameter("prove");

         java.sql.Date date = Date.valueOf(req.getParameter("date"));
         long age = Long.parseLong(req.getParameter("age"));
         String school = req.getParameter("school");
         long schoolage = Long.parseLong(req.getParameter("schoolage"));
        //System.out.println(userid+name+deep+place+prove+date+age+school+schoolage);
        UserServiceImpl userService =new UserServiceImpl();
        StuUser user = new StuUser();
        user.setUserid(userid);
        user.setName(name);
        user.setDeep(deep);
        user.setPlace(place);
        user.setProve(prove);
        user.setDate(date);
        user.setAge(age);
        user.setSchool(school);
        user.setSchoolage(schoolage);
        int i = userService.addStuUser(user);
        System.out.println(i);
        if(i!=0){
            PrintWriter out = resp.getWriter();
            out.println("注册成功");
            resp.setHeader("refresh","1,url=frame.jsp");
        }else {
            PrintWriter out = resp.getWriter();
            out.println("注册失败即将返回登录页");
            resp.setHeader("refresh","1,url=login.jsp");

        }

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
}

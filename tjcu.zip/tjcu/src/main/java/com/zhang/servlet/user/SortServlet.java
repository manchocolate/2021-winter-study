package com.zhang.servlet.user;

import com.zhang.utils.JdbcUtils;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class SortServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        PrintWriter writer = resp.getWriter();
        String sorttype = req.getParameter("sorttype");
        String updown = req.getParameter("updown");
        sortStuUser(resp,sorttype,updown);
        writer.println("<a href=\"register.jsp\">注册</a>\n" +
                "    <a href=\"delete.jsp\">根据id删除信息</a>\n" +
                "    <a href=\"update.jsp\">根据id修改信息</a>\n" +
                "    <a href=\"/tjcu_war/show.do\">查询所有信息</a>\n" +
                "    <a href=\"query.jsp\">id和贫困程度查询</a>"+
                "    <a href=\"sort.jsp\">排序</a>");
    }



    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
    public void sortStuUser(HttpServletResponse resp,String sorttype,String updown){
        Connection con =null;
        PreparedStatement sta = null;
        ResultSet rs =null;
        PrintWriter out = null;
        try {
            out = resp.getWriter();
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            String sql = "select * from stu_user order by "+sorttype+" "+updown;
            con= JdbcUtils.getConnection();
            sta = con.prepareStatement(sql);
            rs = sta.executeQuery();
            System.out.println(sorttype);
            System.out.println(updown);
            /*System.out.println(rs.getString("userid"));*/
            while (rs.next()){
                out.println(
                        "id:"+
                                rs.getString("userid")+"   "+
                                "年龄:"+
                                rs.getLong("age")+"   "+
                                "贫困程度:"+
                                rs.getString("deep")+"   "+
                                "日期:"+
                                rs.getDate("date")+"   "+
                                "姓名:"+
                                rs.getString("name")+"   "+
                                "籍贯:"+
                                rs.getString("place")+"   "+
                                "学制:"+
                                rs.getLong("schoolage")+"   "+
                                "证明:"+
                                rs.getString("prove")+"   "+
                                "学校:"+
                                rs.getString("school")+"<br>"
                );
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }finally {
            JdbcUtils.release(con,sta,rs);
        }
    }
}


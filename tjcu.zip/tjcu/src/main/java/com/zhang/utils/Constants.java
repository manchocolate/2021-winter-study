package com.zhang.utils;

public class Constants {
    public final static String USER_SESSION ="userSession";

}

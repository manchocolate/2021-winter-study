package com.zhang.utils;


import java.io.InputStream;
import java.sql.*;
import java.util.Properties;

public class JdbcUtils {
    private static String driver =null;
    private static String url = null;
    private static String username = null;
    private static String password = null;
    static {

        try {
            InputStream in = JdbcUtils.class.getClassLoader().getResourceAsStream("db.properties");
            Properties properties = new Properties();
            properties.load(in);


            url = properties.getProperty("url");
            driver = properties.getProperty("driver");
            username = properties.getProperty("username");
            password = properties.getProperty("password");

            Class.forName(driver);

        }catch (Exception e) {
            e.printStackTrace();


        }
    }


    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(url, username, password);

    }
    //查询公共类
    public static ResultSet execute(Connection con,PreparedStatement sta,ResultSet rs,String sql,Object[] params) throws SQLException {
        //编译sql在后面直接执行就可以
        sta =con.prepareStatement(sql);
        con = getConnection();
        //setobject，占位符从1开始 但是数组从0开始
        for (int i = 0; i < params.length; i++) {
            sta.setObject(i+1,params[i]);
        }
        rs = sta.executeQuery();
        return rs;

    }
    //增删改公共方法
    public static int execute(Connection con,String sql,Object[] params, PreparedStatement sta) throws SQLException {
        sta =con.prepareStatement(sql);
        con = getConnection();
        for (int i = 0; i < params.length; i++) {
            sta.setObject(i+1,params[i]);
        }
        int updateRows = sta.executeUpdate();
        return updateRows;
    }
    public static void release(Connection con,PreparedStatement sta,ResultSet rs){
        boolean flag =true;
        if(rs!=null){
            try {
                rs.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
                flag = false;
            }
        }
        if(sta!=null){
            try {
                sta.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
                flag = false;
            }
        }
        if(con!=null){
            try {
                con.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
                flag = false;
            }
        }
    }
}

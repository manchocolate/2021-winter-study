package com.zhang.service.user;

import com.zhang.dao.StuUser.UserDao;
import com.zhang.dao.StuUser.UserDaoImpl;
import com.zhang.pojo.StuUser;
import com.zhang.utils.JdbcUtils;
import jakarta.servlet.http.HttpServletResponse;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserServiceImpl implements UserService
{
    //业务处理 调取DAO层  引入dao层
    private UserDao userDao;
    public  UserServiceImpl(){
        userDao = new UserDaoImpl();
    }
    @Override
    public StuUser login(String name, String id) {
        Connection con = null;
        StuUser user =null;
        try {
            con = JdbcUtils.getConnection();
            user = userDao.getLoginUser(con,name);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }finally {
            JdbcUtils.release(con,null,null);
        }
        return user;
    }
    @Override
    public int addStuUser(StuUser user) {
        Connection con =null;
        PreparedStatement sta =null;
        int i = 0;


        try {
            String sql ="insert into stu_user values(?,?,?,?,?,?,?,?,?)";
            con = JdbcUtils.getConnection();
            sta=con.prepareStatement(sql);
            sta.setString(1,user.getUserid());
            sta.setString(2,user.getName());
            sta.setString(3,user.getDeep());
            sta.setString(4,user.getPlace());
            sta.setString(5,user.getProve());
            sta.setDate(6,user.getDate());
            sta.setLong(7,user.getAge());
            sta.setString(8,user.getSchool());
            sta.setLong(9,user.getSchoolage());
            i = sta.executeUpdate();
            //测试是否成功添加
            /*System.out.println(i);*/

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        finally {
            JdbcUtils.release(con,sta,null);
        }
        return i;
    }

    @Override
    public int deleteStuUser(String id) {
        Connection con = null;
        PreparedStatement sta =null;
        int i = 0;
        try {
            String sql = "delete from stu_user where userid = ?";
            con = JdbcUtils.getConnection();
            sta = con.prepareStatement(sql);
            sta.setString(1,id);
            i = sta.executeUpdate();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }JdbcUtils.release(con,sta,null);
        return i;
    }

    @Override
    public int updateStuUser(StuUser user,String id) {
        Connection con =null;
        PreparedStatement sta =null;
        int i =0;
        try {
            String sql = "update stu_user set userid=? ,name=?,deep=?,place=?,prove=?,date=?,age=?,school=?,school=? where userid=? ";
            con=JdbcUtils.getConnection();
            sta = con.prepareStatement(sql);
            sta.setString(1,user.getUserid());
            sta.setString(2,user.getName());
            sta.setString(3,user.getDeep());
            sta.setString(4,user.getPlace());
            sta.setString(5,user.getProve());
            sta.setDate(6,user.getDate());
            sta.setLong(7,user.getAge());
            sta.setString(8,user.getSchool());
            sta.setLong(9,user.getSchoolage());
            sta.setString(10,id);
            i =sta.executeUpdate();

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }finally {
            JdbcUtils.release(con,sta,null);
        }
        return i;
    }

    /*@Test
    public void test(){
        UserServiceImpl userService = new UserServiceImpl();
        StuUser zhangwenjie = userService.login("zhangwenjie", "998");
        System.out.println(zhangwenjie.getAge());
    }*/

}

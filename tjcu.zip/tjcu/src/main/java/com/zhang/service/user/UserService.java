package com.zhang.service.user;

import com.zhang.pojo.StuUser;

import java.sql.ResultSet;
import java.sql.SQLException;

public interface UserService {
    //用户登录
    public StuUser login(String name,String id);
    public int    addStuUser(StuUser user) throws SQLException;
    public int    deleteStuUser(String id);
    public int    updateStuUser(StuUser user,String id);

}
